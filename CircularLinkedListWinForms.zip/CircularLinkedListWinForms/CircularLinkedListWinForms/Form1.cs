﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CircularLinkedListWinForms
{
    public partial class Form1 : Form
    {
        private CircularLinkedList list;

        public Form1()
        {
            InitializeComponent();
            list = new CircularLinkedList();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            int data;
            if (int.TryParse(txtInput.Text, out data))
            {
                list.Add(data);
                list.Display(listBox);
                txtInput.Clear();
            }
            else
            {
                MessageBox.Show("لطفاً یک عدد معتبر وارد کنید.");
            }
        }

        private void BtnRemove_Click_1(object sender, EventArgs e)
        {
            int data;
            if (int.TryParse(txtInput.Text, out data))
            {
                list.Remove(data);
                list.Display(listBox);
                txtInput.Clear();
            }
            else
            {
                MessageBox.Show("لطفاً یک عدد معتبر وارد کنید.");
            }
        }
    }
}

