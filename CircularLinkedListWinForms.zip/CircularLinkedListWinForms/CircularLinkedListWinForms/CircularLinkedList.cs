﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Windows.Forms;

namespace CircularLinkedListWinForms
{
    public class Node
    {
        public int Data;
        public Node Next;

        public Node(int data)
        {
            Data = data;
            Next = null;
        }
    }

    public class CircularLinkedList
    {
        private Node Head;

        public CircularLinkedList()
        {
            Head = null;
        }

        public void Add(int data)
        {
            Node newNode = new Node(data);
            if (Head == null)
            {
                Head = newNode;
                Head.Next = Head;
            }
            else
            {
                Node temp = Head;
                while (temp.Next != Head)
                {
                    temp = temp.Next;
                }
                temp.Next = newNode;
                newNode.Next = Head;
            }
        }

        public void Remove(int data)
        {
            if (Head == null)
                return;

            if (Head.Data == data)
            {
                if (Head.Next == Head)
                {
                    Head = null;
                }
                else
                {
                    Node temp = Head;
                    while (temp.Next != Head)
                    {
                        temp = temp.Next;
                    }
                    temp.Next = Head.Next;
                    Head = Head.Next;
                }
                return;
            }

            Node current = Head;
            Node previous = null;
            do
            {
                previous = current;
                current = current.Next;

                if (current.Data == data)
                {
                    previous.Next = current.Next;
                    return;
                }
            } while (current != Head);
        }

        public void Display(ListBox listBox)
        {
            listBox.Items.Clear();
            if (Head == null)
            {
                listBox.Items.Add("لیست خالی است.");
                return;
            }

            Node temp = Head;
            do
            {
                listBox.Items.Add(temp.Data);
                temp = temp.Next;
            } while (temp != Head);
        }
    }
}

